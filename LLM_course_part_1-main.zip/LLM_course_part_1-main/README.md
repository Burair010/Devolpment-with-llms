# LLM_course_part_1
Course notebooks and all the code for the first LLM course.


Make sure you add your environment variables.



Check out the course video here: https://youtu.be/joxIVe7cOKo

